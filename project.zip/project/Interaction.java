package project;
//importing scanner class for user input
import java.util.Scanner;
public class Interaction {
    public static void main(String [] args) {
       Menu menu = new Menu();
        System.out.println(menu.toString());
    }}